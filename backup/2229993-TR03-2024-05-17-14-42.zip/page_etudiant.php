<?php
session_start();

// Check if the user is not a student or not logged in
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'etudiant') {
    // Redirect to the login page or any other page as needed
    header("Location: index.php");
    exit();
}

include "bd.php"; // Assuming this file contains your database connection





// Check if the disconnect button is clicked
if (isset($_POST['disconnect'])) {
    // Destroy all session data
    session_unset();
    session_destroy();
    // Redirect to the login page or any other page as needed
    header("Location: index.php");
    exit();
}

// Initialize the session type variable
$_SESSION['type'] = "";

// Fetch data from the database
// Prepare SQL query
$sql_etudiant = "SELECT * FROM journal WHERE numetu = '{$_SESSION['user_id']}'";
$result_etudiant = mysqli_query($con, $sql_etudiant);

// Loop through the fetched data
while ($row = mysqli_fetch_assoc($result_etudiant)) {
    $_SESSION['type'] = "Bonjours " . $row['NomEtu'];
}



// Fetch data from the database
// Prepare SQL query
$sql_etudiant = "SELECT * FROM journal WHERE numetu = '{$_SESSION['user_id']}'";
$result_etudiant = mysqli_query($con, $sql_etudiant);

// Check if there is a row fetched
if ($row = mysqli_fetch_assoc($result_etudiant)) {
    // Retrieve and store values from the fetched row
    $userName = $row['NomEtu']; // Assuming 'NomEtu' is the column you want to store as the user's name
    $userSupervisor = $row['nomsup']; // Assuming 'nomsup' is the column for supervisor's name
} else {
    // If no row is fetched, set $userName and $userSupervisor to empty strings or handle it as needed
    $userName = "";
    $userSupervisor = "";
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $date = $_POST['date'];
    $activity1 = $_POST['activity1'];
    $activity2 = $_POST['activity2'];
    $learning1 = $_POST['learning1'];
    $learning2 = $_POST['learning2'];
    $difficulty1 = $_POST['difficulty1'];
    $difficulty2 = $_POST['difficulty2'];
    $comment1 = $_POST['comment1'];
    $comment2 = $_POST['comment2'];

    // Insert data into the database including the user's name
    $sql_insert = "INSERT INTO journal (numetu, NomEtu, nomsup, DateJournal, AS1, AS2, AR1, AR2, DR1, DR2, C1, C2) VALUES ('{$_SESSION['user_id']}', '$userName', '$userSupervisor', '$date', '$activity1', '$activity2', '$learning1', '$learning2', '$difficulty1', '$difficulty2', '$comment1', '$comment2')";

    if (mysqli_query($con, $sql_insert)) {
        echo "Nouveau Rapport Enrigistré";
    } else {
        echo "Error: " . $sql_insert . "<br>" . mysqli_error($con);
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Results</title>
    <style>
         * {
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
            color: #333;
        }
        .header {
            background-color: #333;
            color: #fff;
            padding: 20px 0;
            text-align: center;
        }
        .menu {
            background-color: #444;
            padding: 10px 20px;
            display: flex;
            align-items: center; /* Center items vertically */
        }
        .menu p {
            margin: 0; /* Remove default margin */
            margin-right: auto; /* Push the paragraph to the left */
            color: #fff;
            font-weight: bold;
        }
        .menu ul {
            list-style-type: none; /* Remove bullet points */
            margin: 0; /* Remove default margin */
            padding: 0; /* Remove default padding */
            display: flex;
            align-items: center; /* Center items vertically */
        }
        .menu li {
            margin-right: 10px; /* Add spacing between menu items */
        }
        .menu a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .menu a:hover {
            background-color: #555;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
            background-color: #fff;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            color: #333;
        }
        img {
            vertical-align: middle;
            max-width: 100%;
            height: auto;
        }

        .container {
            max-width: 900px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.6);
        }
        h2 {
            margin-top: 0;
            color: #333;
            text-align: center;
        }
        .text {
            margin-bottom: 20px;
            color: #333;
            text-align: center;
            font-weight: bold; /* Make the text bold */
            text-decoration: underline; /* Add underline */
            padding: 20px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
            color: #555;
        }
        textarea {
            width: calc(100% - 24px);
            padding: 10px;
            border: 3px solid #C7C7C7;
            border-radius: 5px;
            box-sizing: border-box;
        }
        textarea {
            height: 100px;
        }
        input[type="submit"], input[type="reset"] {
            background-color: #333;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            width: 100%;
            margin-top: 10px;
        }

        input[type="submit"]:hover, input[type="reset"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="header">
    <h1>Formulaire de rapport d’étape</h1>
    <div class="menu">
        <p><?php echo $_SESSION['type']; ?></p>
        <ul>
            <li><a href="dash_etudiant.php">Retourner</a></li>

            <li id="disconnect"><a>Déconnecter</a></li>

        </ul>
    </div>
</div>
<!-- Hidden form for logout -->
<form id="logoutForm" method="post" action="">
    <input type="hidden" name="disconnect">
</form>
<script>
    document.getElementById('disconnect').addEventListener('click', function() {
        // Submit the form when the "Déconnecter" li element is clicked
        document.getElementById('logoutForm').submit();
    });
</script>


<div class="container">
    <h2>Rapport d'étape</h2>
    <form action="dash_etudiant.php" method="post" id="myForm">
    <!-- Activités significatives : -->
    <p class="text">Rapport d'étape créé par <?php echo $userName; ?> et remis à  <?php echo $userSupervisor; ?> le <?php echo date('Y-m-d'); ?></p>
    <hr>
    <p>Rapport d'étape est un outil de réflexion personnalisé; tout au long de son stage, la ou le stagiaire y consigne plus particulièrement les tâches professionnelles qu’elle ou qu'il accomplit dans l'entreprise ainsi que les apprentissages que ces dernières lui permettent de réaliser.  </p>
	<h3>Objectifs  </h3>
	<p><ul><li>Objectiver de façon continue son vécu professionnel.</li>
	<li> Consigner ses réflexions. </li></ul></p>
	<h3> Directives</h3>
	<p> Tout au long de son stage, la ou le stagiaire doit complétéer des rapports d'étapes. <strong>Deux ou trois fois dans la session</strong>, elle ou il complète un rapport d'étape et le transmet à son superviseur de stage par l'entremise du site Web de stages. </p>
	<hr>		  
    <h3>Activités significatives :</h3>
    
    <div class="form-group">
        <label for="activity1">Veuillez entrer une première activité significative cette semaine :</label>
        <textarea id="activity1" name="activity1" required></textarea>
    </div>
    <div class="form-group">
        <label for="activity2">Veuillez entrer une deuxième activité significative cette semaine :</label>
        <textarea id="activity2" name="activity2" required></textarea>
    </div>
    <hr>
    <!-- Apprentissages réalisés : -->
    <h3>Apprentissages réalisés :</h3>
    <div class="form-group">
        <label for="learning1">Veuillez indiquer l'apprentissage relié à la première activité significative :</label>
        <textarea id="learning1" name="learning1" required></textarea>
    </div>
    <div class="form-group">
        <label for="learning2">Veuillez indiquer l'apprentissage relié à la deuxième activité significative :</label>
        <textarea id="learning2" name="learning2" required></textarea>
    </div>
    <hr>
    <!-- Difficultés rencontrées (s'il y a lieu) : -->
    <h3>Difficultés rencontrées (s'il y a lieu) :</h3>
    <div class="form-group">
        <label for="difficulty1">Veuillez indiquer une première difficulté rencontrée :</label>
        <textarea id="difficulty1" name="difficulty1" required></textarea>
    </div>
    <div class="form-group">
        <label for="difficulty2">Veuillez indiquer une deuxième difficulté rencontrée :</label>
        <textarea id="difficulty2" name="difficulty2" required></textarea>
    </div>
    <hr>
    <!-- Commentaires - Questions : -->
    <h3>Commentaires - Questions :</h3>
    <div class="form-group">
        <label for="comment1">Veuillez indiquer un premier commentaire ou une question pertinente :</label>
        <textarea id="comment1" name="comment1" required></textarea>
    </div>
    <div class="form-group">
        <label for="comment2">Veuillez indiquer un deuxième commentaire ou une question pertinente :</label>
        <textarea id="comment2" name="comment2" required></textarea>
    </div>
    

    <div class="form-group">
    <label for="date">Date:</label>
    <input type="text" id="date" name="date" value="<?php echo date('Y-m-d'); ?>" readonly required>
    </div>
    <input type="submit" value="Envoyer">
    <input type="reset" value="Réinitialiser">
</form>
</div>
<script>
    document.getElementById('myForm').addEventListener('submit', function(event) {
        // Reload the page when the form is submitted
        location.reload();
    });
</script>


</body>
</html>
