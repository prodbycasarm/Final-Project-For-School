<?php
session_start();

// Check if the user is not a student or not logged in
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'etudiant') {
    // Redirect to the login page or any other page as needed
    header("Location: index.php");
    exit();
}

include "bd.php"; // Assuming this file contains your database connection





// Check if the disconnect button is clicked
if (isset($_POST['disconnect'])) {
    // Destroy all session data
    session_unset();
    session_destroy();
    // Redirect to the login page or any other page as needed
    header("Location: index.php");
    exit();
}

// Initialize the session type variable
$_SESSION['type'] = "";

// Fetch data from the database
// Prepare SQL query
$sql_etudiant = "SELECT * FROM journal WHERE numetu = '{$_SESSION['user_id']}'";
$result_etudiant = mysqli_query($con, $sql_etudiant);

// Loop through the fetched data
while ($row = mysqli_fetch_assoc($result_etudiant)) {
    $_SESSION['type'] = "Bonjours " . $row['NomEtu'];
}



// Fetch data from the database
// Prepare SQL query
$sql_etudiant = "SELECT * FROM journal WHERE numetu = '{$_SESSION['user_id']}'";
$result_etudiant = mysqli_query($con, $sql_etudiant);

// Check if there is a row fetched
if ($row = mysqli_fetch_assoc($result_etudiant)) {
    // Retrieve and store values from the fetched row
    $userName = $row['NomEtu']; // Assuming 'NomEtu' is the column you want to store as the user's name
    $userSupervisor = $row['nomsup']; // Assuming 'nomsup' is the column for supervisor's name
} else {
    // If no row is fetched, set $userName and $userSupervisor to empty strings or handle it as needed
    $userName = "";
    $userSupervisor = "";
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $date = $_POST['date'];
    $activity1 = $_POST['activity1'];
    $activity2 = $_POST['activity2'];
    $learning1 = $_POST['learning1'];
    $learning2 = $_POST['learning2'];
    $difficulty1 = $_POST['difficulty1'];
    $difficulty2 = $_POST['difficulty2'];
    $comment1 = $_POST['comment1'];
    $comment2 = $_POST['comment2'];

    // Insert data into the database including the user's name
    $sql_insert = "INSERT INTO journal (numetu, NomEtu, nomsup, DateJournal, AS1, AS2, AR1, AR2, DR1, DR2, C1, C2) VALUES ('{$_SESSION['user_id']}', '$userName', '$userSupervisor', '$date', '$activity1', '$activity2', '$learning1', '$learning2', '$difficulty1', '$difficulty2', '$comment1', '$comment2')";

    if (mysqli_query($con, $sql_insert)) {
        echo "Nouveau Rapport Enrigistré";
    } else {
        echo "Error: " . $sql_insert . "<br>" . mysqli_error($con);
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rapport d'étape</title>
    <style>
         * {
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
            color: #333;
        }
        .header {
            background-color: #333;
            color: #fff;
            padding: 20px 0;
            text-align: center;
        }
        .menu {
            background-color: #444;
            padding: 10px 20px;
            display: flex;
            align-items: center; /* Center items vertically */
        }
        .menu p {
            margin: 0; /* Remove default margin */
            margin-right: auto; /* Push the paragraph to the left */
            color: #fff;
            font-weight: bold;
        }
        .menu ul {
            list-style-type: none; /* Remove bullet points */
            margin: 0; /* Remove default margin */
            padding: 0; /* Remove default padding */
            display: flex;
            align-items: center; /* Center items vertically */
        }
        .menu li {
            margin-right: 10px; /* Add spacing between menu items */
        }
        .menu a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .menu a:hover {
            background-color: #555;
        }
        
        .container {
            max-width: 900px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.6);
        }
        h2 {
            margin-top: 0;
            color: #333;
            text-align: center;
        }
        table {
            border-collapse: collapse;
            width: 70%;
            margin-top: 20px;
            background-color: #fff;
            margin-left: auto;
            margin-right: auto;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            color: #333;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #ddd;
        }
        img {
            vertical-align: middle;
            max-width: 100%;
            height: auto;
        }

    </style>
</head>
<body>

<div class="header">
    <h1>Voici Vos Rapports D'étape</h1>
    <div class="menu">
        <p><?php echo $_SESSION['type']; ?></p>
        <ul>
            <li>Vous avez <?php echo mysqli_num_rows($result_etudiant); ?> de rapports d'étape.</li>
            <li><a href="page_etudiant.php">Créer Un Nouveau Rapport</a></li>
            <li id="disconnect"><a>Déconnecter</a></li>

        </ul>
    </div>
</div>
<!-- Hidden form for logout -->
<form id="logoutForm" method="post" action="">
    <input type="hidden" name="disconnect">
</form>
<script>
    document.getElementById('disconnect').addEventListener('click', function() {
        // Submit the form when the "Déconnecter" li element is clicked
        document.getElementById('logoutForm').submit();
    });
</script>

<?php
// Check if there is a row fetched
if ($row = mysqli_fetch_assoc($result_etudiant)) {
    // Retrieve and store values from the fetched row
    $userName = $row['NomEtu']; // Assuming 'NomEtu' is the column you want to store as the user's name
    $userSupervisor = $row['nomsup']; // Assuming 'nomsup' is the column for supervisor's name
} else {
    // If no row is fetched, set $userName and $userSupervisor to empty strings or handle it as needed
    $userName = "";
    $userSupervisor = "";
}
?>
<table style="border-collapse: collapse; width: 70%;">
    <tr>
        <th style="border: 1px solid black; padding: 8px; text-align: center;">Numéro</th>
        <th style="border: 1px solid black; padding: 8px;">Date</th>
        <th style="border: 1px solid black; padding: 8px;">Action</th>
    </tr>
    <?php
    // Reset the data pointer to the beginning of the result set
    mysqli_data_seek($result_etudiant, 0);
    
    // Initialize a counter for the number of DateJournal entries
    $counter = 1;

    while ($row = mysqli_fetch_assoc($result_etudiant)) {
        ?>
        <tr>
            <td style="border: 1px solid black; padding: 8px; text-align: center;"><?php echo $counter; ?></td>
            <td style="border: 1px solid black; padding: 8px;"><?php echo $row['DateJournal']; ?></td>
            <td style="border: 1px solid black; padding: 8px;">
                <?php 
                // Check if there is a row fetched
                if ($row) {
                    // Retrieve and store values from the fetched row
                    $userName = $row['NomEtu']; // Assuming 'NomEtu' is the column you want to store as the user's name
                    $userSupervisor = $row['nomsup']; // Assuming 'nomsup' is the column for supervisor's name
                    $rapport_etape_link = "rapport_etape.php?num=" . $row['numero'];
                    ?>
                    <a href="<?php echo $rapport_etape_link; ?>">
                        <img src="logo.png"  width="20" height="20">
                    </a>
                    <?php
                } else {
                    // If no row is fetched, set $userName and $userSupervisor to empty strings or handle it as needed
                    $userName = "";
                    $userSupervisor = "";
                }
                ?>
            </td>
        </tr>
        <?php
        // Increment the counter
        $counter++;
    }
    ?>
</table>

</body>
</html>
