-- phpMyAdmin SQL Dump
-- version 
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : lun. 14 nov. 2022 à 17:56
-- Version du serveur : 5.7.36-39-log
-- Version de PHP : 8.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `marcaube_proprio`
--

-- --------------------------------------------------------

--
-- Structure de la table `proprietaire`
--

CREATE TABLE `proprietaire` (
  `numlot` int(5) NOT NULL,
  `nomproprio` varchar(25) NOT NULL,
  `adresse` varchar(50) NOT NULL,
  `ville` varchar(25) NOT NULL,
  `province` varchar(25) NOT NULL,
  `taxes` float(9,2) NOT NULL,
  `latitude` varchar(200) NOT NULL,
  `longitude` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `proprietaire`
--

INSERT INTO `proprietaire` (`numlot`, `nomproprio`, `adresse`, `ville`, `province`, `taxes`, `latitude`, `longitude`) VALUES
(10001, 'Marc', '123 St-Jacques', 'Chelsea', 'Québec', 2400.00, '45.4592538', '-75.77199'),
(10002, 'Johanne', '123 St-Jean', 'Gatineau', 'Québec', 3000.00, '45.4711196', '-75.7444263'),
(10003, 'Pierre', '888 Mont-Bleu', 'Gatineau', 'Québec', 4000.00, '45.4560236', '-75.7684988'),
(10004, 'François', '999 Route 148', 'Cantley', 'Québec', 1500.00, '45.433418', '-75.663316'),
(10005, 'Jean', '123 rue Boudreau', 'Gatineau', 'Québec', 10000.00, '45.478895', '-75.6520697'),
(10006, 'Marc', '124 St-Jacques', 'Chelsea', 'Québec', 2600.00, '45.42406552084053', '-75.73410947811293');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `proprietaire`
--
ALTER TABLE `proprietaire`
  ADD PRIMARY KEY (`numlot`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
