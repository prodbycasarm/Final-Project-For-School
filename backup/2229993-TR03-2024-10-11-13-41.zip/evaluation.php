<?php
session_start();

// Check if the user is not a student or not logged in
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'etudiant') {
    // Redirect to the login page or any other page as needed
    header("Location: index.php");
    exit();
}

include "bd.php"; // Assuming this file contains your database connection





// Check if the disconnect button is clicked
if (isset($_POST['disconnect'])) {
    // Destroy all session data
    session_unset();
    session_destroy();
    // Redirect to the login page or any other page as needed
    header("Location: index.php");
    exit();
}

// Initialize the session type variable
$_SESSION['type'] = "";

// Fetch data from the database
// Prepare SQL query
$sql_etudiant = "SELECT * FROM journal WHERE numetu = '{$_SESSION['user_id']}'";
$result_etudiant = mysqli_query($con, $sql_etudiant);

// Loop through the fetched data
while ($row = mysqli_fetch_assoc($result_etudiant)) {
    $_SESSION['type'] = "Bonjours " . $row['NomEtu'];
}



// Fetch data from the database
// Prepare SQL query
$sql_etudiant = "SELECT * FROM journal WHERE numetu = '{$_SESSION['user_id']}'";
$result_etudiant = mysqli_query($con, $sql_etudiant);

// Check if there is a row fetched
if ($row = mysqli_fetch_assoc($result_etudiant)) {
    // Retrieve and store values from the fetched row
    $userName = $row['NomEtu']; // Assuming 'NomEtu' is the column you want to store as the user's name
    $userSupervisor = $row['nomsup']; // Assuming 'nomsup' is the column for supervisor's name
} else {
    // If no row is fetched, set $userName and $userSupervisor to empty strings or handle it as needed
    $userName = "";
    $userSupervisor = "";
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $date = $_POST['date'];
    $activity1 = $_POST['activity1'];
    $activity2 = $_POST['activity2'];
    $learning1 = $_POST['learning1'];
    $learning2 = $_POST['learning2'];
    $difficulty1 = $_POST['difficulty1'];
    $difficulty2 = $_POST['difficulty2'];
    $comment1 = $_POST['comment1'];
    $comment2 = $_POST['comment2'];

    // Insert data into the database including the user's name
    $sql_insert = "INSERT INTO journal (numetu, NomEtu, nomsup, DateJournal, AS1, AS2, AR1, AR2, DR1, DR2, C1, C2) VALUES ('{$_SESSION['user_id']}', '$userName', '$userSupervisor', '$date', '$activity1', '$activity2', '$learning1', '$learning2', '$difficulty1', '$difficulty2', '$comment1', '$comment2')";

    if (mysqli_query($con, $sql_insert)) {
        echo "Nouveau Rapport Enrigistré";
    } else {
        echo "Error: " . $sql_insert . "<br>" . mysqli_error($con);
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rapports de Stage - 2023 Etudiant1</title>
    <style>
         * {
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
            color: #333;
        }
        .header {
            background-color: #333;
            color: #fff;
            padding: 20px 0;
            text-align: center;
        }
        .menu {
            background-color: #444;
            padding: 10px 20px;
            display: flex;
            align-items: center; /* Center items vertically */
        }
        .menu p {
            margin: 0; /* Remove default margin */
            margin-right: auto; /* Push the paragraph to the left */
            color: #fff;
            font-weight: bold;
        }
        .menu ul {
            list-style-type: none; /* Remove bullet points */
            margin: 0; /* Remove default margin */
            padding: 0; /* Remove default padding */
            display: flex;
            align-items: center; /* Center items vertically */
        }
        .menu li {
            margin-right: 10px; /* Add spacing between menu items */
        }
        .menu a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .menu a:hover {
            background-color: #555;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
            background-color: #fff;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            color: #333;
        }
        img {
            vertical-align: middle;
            max-width: 100%;
            height: auto;
        }

        .container {
            max-width: 900px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.6);
        }
        .flex-container {
            display: flex;
            justify-content: space-between;
            gap: 20px;
            margin-bottom: 20px;
        }

        /* Flex item styling */
        .flex-container .col-sm-6 {
            width: 48%; /* Ensures they are next to each other with some space */
        }
        h2 {
            margin-top: 0;
            color: #333;
            text-align: center;
        }
        .text {
            margin-bottom: 20px;
            color: #333;
            text-align: center;
            font-weight: bold; /* Make the text bold */
            text-decoration: underline; /* Add underline */
            padding: 20px;
        }
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
            resize: vertical;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
            color: #555;
        }
        textarea {
            width: calc(100% - 24px);
            padding: 10px;
            border: 3px solid #C7C7C7;
            border-radius: 5px;
            box-sizing: border-box;
        }
        textarea {
            height: 100px;
        }
        input[type="submit"], input[type="reset"] {
            background-color: #333;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            width: 100%;
            margin-top: 10px;
        }

        input[type="submit"]:hover, input[type="reset"]:hover {
            background-color: #0056b3;
        }
        .col-sm-12 {
    width: 100%;
    padding-right: 15px;
    padding-left: 15px;
    margin-bottom: 20px;
}

.col-sm-6 {
    width: 50%;
    padding-right: 15px;
    padding-left: 15px;
    margin-bottom: 20px;
}
    </style>
</head>
<body>

<div class="header">
    <h1>Évaluation de l'entreprise</h1>
    <div class="menu">
        <p><?php echo $_SESSION['type']; ?></p>
        <ul>
            <li><a href="dash_etudiant.php">Retourner</a></li>

            <li id="disconnect"><a>Déconnecter</a></li>

        </ul>
    </div>
</div>
<!-- Hidden form for logout -->
<form id="logoutForm" method="post" action="">
    <input type="hidden" name="disconnect">
</form>
<script>
    document.getElementById('disconnect').addEventListener('click', function() {
        // Submit the form when the "Déconnecter" li element is clicked
        document.getElementById('logoutForm').submit();
    });
</script>





<div class="container">
<section class="contenu">
		
		<div class="row">
					
		
			
			
			
			<div class="col-sm-12">

		<!-- FORMS -->
		<h3>Évaluation du stage</h3>
		<p class="create">Évaluation du stage créé par <?php echo $userName; ?> et remis à  <?php echo $userSupervisor; ?> le <?php echo date('Y-m-d'); ?></p>
		<form name="evalstage" action="" method="post">
		   
			<legend>1. Parmi les objectifs que vous avez retenus à l'intérieur du plan de votre stage, lesquels avez-vous atteints ? </legend> <p>Pour vous aider à les identifier, consultez votre plan, ANNEXE 1, et vos rapports de stage, ANNEXE 2.	 <br /><br /></legend>
			Attitudes personnelles (objectifs g&eacute;n&eacute;raux) :</p>
			<div class="flex-container">
                <p class="col-sm-6"><label class="label_txt" for="question1a"> a.</label>
			        <textarea name="champ1" id="question1a" cols="50" rows="8" class="requis"></textarea>
                </p>	
			
                <p class="col-sm-6"><label class="label_txt" for="question1b">b.</label>
                    <textarea name="champ2" id="question1b" cols="50" rows="8" class="requis"></textarea> 
                </p>
            </div>
			<div style="clear:both"></div>
			
			<p>Habilet&eacute;s professionnelles (objectifs sp&eacute;cifiques) :</p>
			<p class="col-sm-6"><label class="label_txt" for="question1a-2">a.</label>
			<textarea name="champ3" id="question1a-2" cols="50" rows="8" class="requis"></textarea></p>
			
			<p class="col-sm-6"><label class="label_txt" for="question1b-2">b.</label>
			<textarea name="champ4" id="question1b-2" cols="50" rows="8" class="requis"></textarea></p>
		  
			<label class="label_txt" for="question1-5">Pourquoi et comment &ecirc;tes-vous parvenue ou parvenu &agrave; atteindre ces objectifs ?</label>	
			<textarea name="champ5" id="question1-5" cols="50" rows="8" class="requis"></textarea>
		 
		  
		  
			<legend>2. S'il y a lieu, identifiez quelques objectifs que vous n&rsquo;avez pas atteints de fa&ccedil;on satisfaisante.</legend>
			<p>Attitudes personnelles :</p>	
			<p class="col-sm-6"><label class="label_txt" for="question2a">a.</label>
			<textarea name="champ6" id="question2a" cols="50" rows="8" class="requis"></textarea></p>
			<p class="col-sm-6"><label class="label_txt" for="question2b">b.</label>
			<textarea name="champ7" id="question2b" cols="50" rows="8" class="requis"></textarea></p>
			<div style="clear:both"></div>
			
			<p>Habilet&eacute;s professionnelles</p>
			<p class="col-sm-6"><label class="label_txt" for="question2a-2">a.</label>
			<textarea name="champ8" id="question2a-2" cols="50" rows="8" class="requis"></textarea></p>
			<p class="col-sm-6"><label class="label_txt" for="question2b-2">b.</label>
			<textarea name="champ9" id="question2b-2" cols="50" rows="8" class="requis"></textarea></p>
			<label class="label_txt" for="question2-5">Pourquoi n'avez-vous pas r&eacute;ussi &agrave; les atteindre ?</label>
			<textarea name="champ10" id="question2-5" cols="50" rows="8" class="requis"></textarea>
		 
		  
		  
			<legend><label class="label_txt_num" for="question3a">3. S'il y a lieu, identifiez les craintes que vous aviez au regard du stage avant de l'entreprendre ?</label></legend>
			<textarea name="champ11" id="question3a" cols="50" rows="8" class="requis"></textarea>
			<label class="label_txt" for="question3b">Parmi vos craintes (si vous en aviez), lesquelles &eacute;taient justifi&eacute;es et lesquelles ne l'&eacute;taient pas ? </label>
			<p>Commentez tr&egrave;s bri&egrave;vement votre r&eacute;ponse.</p>	
			<textarea name="champ12" id="question3b" cols="50" rows="8" class="requis"></textarea> 
		  
		  
		     
			<legend>4. Identifiez les impacts que votre s&eacute;jour en entreprise a eus sur vous, d 'une part, et sur l'entreprise, d 'autre part.</legend>
			<label class="label_txt" for="question4a">a. Pour vous : (votre vie personelle, vos &eacute;tudes, etc.)</label>
			<textarea name="champ13" id="question4a" cols="50" rows="8" class="requis"></textarea>
			<label class="label_txt" for="question4b">b. Pour l'entreprise :</label>
			<textarea name="champ14" id="question4b" cols="50" rows="8" class="requis"></textarea>
		  
		  
		    
			<legend><label class="label_txt_num" for="question5">5. Votre stage affectera-t-il votre orientation professionnelle ?</label></legend>
			<p>Justifiez votre r&eacute;ponse.</p>
			<textarea name="champ15" id="question5" cols="50" rows="8" class="requis"></textarea>
		  
		  
		   
			<legend><label class="label_txt_num" for="question6">6. En quoi votre stage a-t-il valid&eacute; ou plus ou moins invalid&eacute; la formation que vous avez re&ccedil;ue au C&eacute;gep de l&rsquo;Outaouais ?</label></legend>	
			<textarea name="champ16" id="question6" cols="50" rows="8" class="requis"></textarea>
		 
		  
		   
			<legend><label class="label_txt_num" for="question7">7. Suite &agrave; l'exp&eacute;rience que vous avez v&eacute;cue en entreprise, pouvez-vous d&eacute;gager une ou des faiblesses qu'aurait votre formation ?</label></legend>
			<p>Si oui, lesquelles ?</p>
			<textarea name="champ17" id="question7" cols="50" rows="8" class="requis"></textarea>
		  
		  
		 
			<legend><label class="label_txt_num" for="question8"> 
			8. Suite &agrave; l'exp&eacute;rience que vous avez v&eacute;cue en stage, identifiez, s'il y a lieu, les &eacute;l&eacute;ments qui devraient pr&eacute;f&eacute;rablement &ecirc;tre ajout&eacute;s &agrave; notre programme. </label></legend>	
			<textarea name="champ18" id="question8" cols="50" rows="8" class="requis"></textarea>
		  
		 	
		
		    <input type="submit" value="Envoyer">
    <input type="reset" value="Réinitialiser">
			
		</form>
		</div>
			</div> 	<!-- COl-12 -->
		</div> 		<!-- ROW -->
	</section> 		<!-- Contenu -->
</section> 			<!-- Container -->	
		
		
		
	</div> 
	</div> 
    </div> 

<script>
    document.getElementById('myForm').addEventListener('submit', function(event) {
        // Reload the page when the form is submitted
        location.reload();
    });
</script>


</body>
</html>
