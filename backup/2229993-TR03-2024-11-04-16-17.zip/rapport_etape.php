<?php
session_start();





// Check if the user is not an étudiant or not logged in
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'etudiant') {
    // Redirect to login page or any other page as needed
    header("Location: index.php");
    exit();
}
include "bd.php"; // Assuming this file contains your database connection
// Set UTF-8 character encoding for MySQL connection
mysqli_set_charset($con, "utf8");

$userName = ""; // Initialize variables
$userSupervisor = ""; // Initialize variables

// Check if $_GET['num'] is set
if(isset($_GET['num'])){
    // Get the value from $_GET['num']
    $num = $_GET['num'];
    
    // Fetch data from the database
    // Prepare SQL query
    $sql_etudiant = "SELECT * FROM journal WHERE numero = '$num'";
    $result_etudiant = mysqli_query($con, $sql_etudiant);

    
    
}



// Check if the disconnect button is clicked
if (isset($_POST['disconnect'])) {
    // Destroy all session data
    session_unset();
    session_destroy();
    // Redirect to the login page
    header("Location: index.php");
    exit();
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Results</title>
</head>
<style>
         * {
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
            color: #333;
        }
        .header {
            background-color: #333;
            color: #fff;
            padding: 20px 0;
            text-align: center;
        }
        .menu {
            background-color: #444;
            padding: 10px 20px;
            display: flex;
            align-items: center; /* Center items vertically */
        }
        .menu p {
            margin: 0; /* Remove default margin */
            margin-right: auto; /* Push the paragraph to the left */
            color: #fff;
            font-weight: bold;
        }
        .menu ul {
            list-style-type: none; /* Remove bullet points */
            margin: 0; /* Remove default margin */
            padding: 0; /* Remove default padding */
            display: flex;
            align-items: center; /* Center items vertically */
        }
        .menu li {
            margin-right: 10px; /* Add spacing between menu items */
        }
        .menu a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .menu a:hover {
            background-color: #555;
        }
        
        .container {
            max-width: 900px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.6);
        }
        h2 {
            margin-top: 0;
            color: #333;
            text-align: center;
        }

        text{
            margin-bottom: 20px;
            color: #333;
            text-align: center;
            font-weight: bold; /* Make the text bold */
            text-decoration: underline; /* Add underline */
            padding: 20px;
        }
        table {
            border-collapse: collapse;
            width: 70%;
            margin-top: 20px;
            background-color: #fff;
            margin-left: auto;
            margin-right: auto;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            color: #333;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #ddd;
        }
        img {
            vertical-align: middle;
            max-width: 100%;
            height: auto;
        }

    </style>
<body>

<div class="header">
    <h1>Rapport d’étape</h1>
    <div class="menu">
        <p><?php echo $_SESSION['type']; ?></p>
        <ul>
            <li><a href="dash_etudiant.php">Retourner</a></li>

            <li id="disconnect"><a>Déconnecter</a></li>

        </ul>
    </div>
</div>
<!-- Hidden form for logout -->
<form id="logoutForm" method="post" action="">
    <input type="hidden" name="disconnect">
</form>
<script>
    document.getElementById('disconnect').addEventListener('click', function() {
        // Submit the form when the "Déconnecter" li element is clicked
        document.getElementById('logoutForm').submit();
    });
</script>
<div class="container">
    

<?php
// Pour le sous titre
if(isset($_GET['NAME'])){
    // Get the value from $_GET['num']
    $num = $_GET['NAME'];
    
    // Fetch data from the database
    // Prepare SQL query
    $sql_etudiant = "SELECT * FROM journal WHERE numero AND numetu = '$name'";
    $result_etudiant = mysqli_query($con, $sql_etudiant);
    

    // Check if there is a row fetched
    if ($row = mysqli_fetch_assoc($result_etudiant)) {
        // Retrieve and store values from the fetched row
        $userName = $row['NomEtu']; // Assuming 'NomEtu' is the column you want to store as the user's name
        $userSupervisor = $row['nomsup']; // Assuming 'nomsup' is the column for supervisor's name
    } else {
        // Handle the case where no row is fetched, for example:
        // Redirect to an error page or display a message
        exit("No data found for the provided number.");
    }
}




?>
    <p class="text" style="text-align: center; font-weight: bold;">Rapport d'étape créé par 
    <?php echo $userName; ?> et remis à  <?php echo $userSupervisor; ?> le <?php echo date('Y-m-d'); ?></p>
    <hr>
    <table style="border-collapse: collapse; width: 90%;">
        <?php
        $rowCount = mysqli_num_rows($result_etudiant); // Get the total number of rows
        $columns = 1; // Number of columns per row
        $rows = ceil($rowCount / $columns); // Calculate the number of rows needed

        for ($i = 0; $i < $rows; $i++) {
            echo '<tr>';
            for ($j = 0; $j < $columns; $j++) {
                $index = $i * $columns + $j;
                if ($index < $rowCount) {
                    $row = mysqli_fetch_assoc($result_etudiant);
                    echo '<td style="border: 1px solid black; padding: 8px; margin: 10px;">';
                    echo '<h3>1. Activités significatives :</h3>' . $row['AS1'] . '<br><br>';
                    echo '<hr>' . $row['AS2'] . '<br><br>';
                    echo '<h3>2. Apprentissages réalisés :</h3>' . $row['AR1'] . '<br><br>';
                    echo '<hr>' . $row['AR2'] . '<br><br>';
                    echo '<h3>3. Difficultés rencontrées (s\'il y a lieu) :</h3>' . $row['DR1'] . '<br><br>';
                    echo '<hr>' . $row['DR2'] . '<br><br>';
                    echo '<h3>4. Commentaires - Questions :</h3>' . $row['C1'] . '<br><br>';
                    echo '<hr>' . $row['C2'] . '<br><br>';
                    echo '</td>';
                } else {
                    echo '<td style="border: 1px solid black; padding: 8px;"></td>';
                }
            }
            echo '</tr>';
        }
        ?>
    </table>
</div>

</body>
</html>
