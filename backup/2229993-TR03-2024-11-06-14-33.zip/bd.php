<?php
	$con = mysqli_connect("localhost","2229993","ookahzucheehahp");
	mysqli_select_db($con,"casarm_stages2024");
?>