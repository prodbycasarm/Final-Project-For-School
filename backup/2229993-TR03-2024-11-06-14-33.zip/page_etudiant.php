<?php
session_start();

// Check if the user is not a student or not logged in
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'etudiant') {
    // Redirect to the login page or any other page as needed
    header("Location: index.php");
    exit();
}

include "bd.php"; // Assuming this file contains your database connection





// Check if the disconnect button is clicked
if (isset($_POST['disconnect'])) {
    // Destroy all session data
    session_unset();
    session_destroy();
    // Redirect to the login page or any other page as needed
    header("Location: index.php");
    exit();
}

// Initialize the session type variable
$_SESSION['type'] = "";

// Fetch data from the database
// Prepare SQL query
$sql_etudiant = "SELECT * FROM journal WHERE numetu = '{$_SESSION['user_id']}'";
$result_etudiant = mysqli_query($con, $sql_etudiant);

// Loop through the fetched data
while ($row = mysqli_fetch_assoc($result_etudiant)) {
    $_SESSION['type'] = "Bonjours " . $row['NomEtu'];
}



// Fetch data from the database
// Prepare SQL query
$sql_etudiant = "SELECT * FROM journal WHERE numetu = '{$_SESSION['user_id']}'";
$result_etudiant = mysqli_query($con, $sql_etudiant);

// Check if there is a row fetched
if ($row = mysqli_fetch_assoc($result_etudiant)) {
    // Retrieve and store values from the fetched row
    $userName = $row['NomEtu']; // Assuming 'NomEtu' is the column you want to store as the user's name
    $userSupervisor = $row['nomsup']; // Assuming 'nomsup' is the column for supervisor's name
} else {
    // If no row is fetched, set $userName and $userSupervisor to empty strings or handle it as needed
    $userName = "";
    $userSupervisor = "";
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $date = $_POST['date'];
    $activity1 = $_POST['activity1'];
    $activity2 = $_POST['activity2'];
    $learning1 = $_POST['learning1'];
    $learning2 = $_POST['learning2'];
    $difficulty1 = $_POST['difficulty1'];
    $difficulty2 = $_POST['difficulty2'];
    $comment1 = $_POST['comment1'];
    $comment2 = $_POST['comment2'];

    // Insert data into the database including the user's name
    $sql_insert = "INSERT INTO journal (numetu, NomEtu, nomsup, DateJournal, AS1, AS2, AR1, AR2, DR1, DR2, C1, C2) VALUES ('{$_SESSION['user_id']}', '$userName', '$userSupervisor', '$date', '$activity1', '$activity2', '$learning1', '$learning2', '$difficulty1', '$difficulty2', '$comment1', '$comment2')";

    if (mysqli_query($con, $sql_insert)) {
        echo "Nouveau Rapport Enrigistré";
    } else {
        echo "Error: " . $sql_insert . "<br>" . mysqli_error($con);
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Results</title>
    <style>
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            }
        /* Container for the main content */
        .container {
            max-width: 900px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.6);
        }

        /* Styles for the table */
        table {
            border-collapse: collapse;
            width: 80%;
            margin: 20px auto;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 15px;
            text-align: left;
            color: #333;
        }

        th {
            background-color: #3A3B3C;
            color: #f2f2f2;
            font-weight: bold;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #e2e3e5;
        }

        /* Navbar styles */
        nav {
            width: 100%;
            background: #242526;
            border-bottom: 2px white solid;
        }

        nav .wrapper {
            max-width: 1300px;
            padding:30px;
            height: 70px;
            line-height: 70px;
            margin: auto;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .wrapper .logo a {
            color: #f2f2f2;
            font-size: 30px;
            font-weight: 600;
            text-decoration: none;
        }

        .nav-links {
            display: inline-flex;
        }

        .nav-links li {
            list-style: none;
        }

        .nav-links li a {
            color: white;
            text-decoration: none;
            font-size: 18px;
            font-weight: 500;
            padding: 9px 15px;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        .sub-menu {
            color: black !important;
        }
  
        .nav-links li a:hover {
            background: #3A3B3C;
            color: white !important;
        }

        /* Header and Title Styles */
        .header {
            background-color: white;
            color: black;
        }

        .titre h1 {
            color: white;
        }
        .header .wrapper {
            display: flex;
            flex-direction: column;
            padding:10px;
            align-items: center; /* Center the menu horizontally */
            text-align: center;
        }

        .header .nav-links {
            display: flex;
            justify-content: center; /* Center menu items within the flex container */
            gap: 15px; /* Optional: space between menu items */
            padding: 20px;
            
        }

        .tous {
            margin-top: 40px;
            text-align: left;
            width: 70%;
            margin: 20px auto;
        }

        /* Responsive adjustments */
        @media screen and (max-width: 970px) {
            .wrapper .nav-links {
                position: fixed;
                height: 100vh;
                width: 100%;
                max-width: 350px;
                top: 0;
                left: -100%;
                background: #242526;
                padding: 50px 10px;
                line-height: 50px;
                box-shadow: 0px 15px 15px rgba(0, 0, 0, 0.18);
                transition: all 0.3s ease;
            }

            .nav-links li {
                margin: 15px 10px;
            }

            .nav-links li a {
                font-size: 20px;
                display: block;
                padding: 0 20px;
            }
        }
        .rapport-link {
            color:black;
        }
        .tableau {
            background-color: #dadada;
            padding: 50px;
            width: 70%;
            margin: 0 auto; /* Centers the container horizontally */
        }
        
    </style>
</head>
<body>
<div class="main">
    <nav>
    <div class="wrapper">
        <div class="titre"><h1 href="#">Stage technique d'intégration multimédia</h1></div>
        <ul class="nav-links">
        <label for="close-btn" class="btn close-btn"><i class="fas fa-times"></i></label>
        <li style="color:white;"><?php echo $_SESSION['type']; ?></li>
        <li><a href="dash_etudiant.php">Accueil</a></li>
        <li id="disconnect"><a>Déconnecter</a></li>
        </ul>
        <label for="menu-btn" class="btn menu-btn"><i class="fas fa-bars"></i></label>
    </div>
    </nav>


    <div class="header">
        <div class="wrapper">
            <ul class="nav-links">
                <li><a class="sub-menu" href="#">Rapports d'étape</a></li>
                <li><a class="sub-menu" href="experience.php">Expériences de stage</a></li>
                <li><a class="sub-menu" href="evaluation.php">Évaluation de l'entreprise</a></li>
            </ul> 
            </div>
    </div>


    <!-- Hidden form for logout -->
    <form id="logoutForm" method="post" action="">
        <input type="hidden" name="disconnect">
    </form>
    <script>
        document.getElementById('disconnect').addEventListener('click', function() {
            // Submit the form when the "Déconnecter" li element is clicked
            document.getElementById('logoutForm').submit();
        });
    </script>


    <div class="tableau">
        <h2>Rapport d'étape</h2>
        <form action="dash_etudiant.php" method="post" id="myForm">
        <!-- Activités significatives : -->
        <p class="text">Rapport d'étape créé par <?php echo $userName; ?> et remis à  <?php echo $userSupervisor; ?> le <?php echo date('Y-m-d'); ?></p>
        <hr>
        <h3>Rapport d'étape  </h3>
        <p>Rapport d'étape est un outil de réflexion personnalisé; tout au long de son stage, la ou le stagiaire y consigne plus particulièrement les tâches professionnelles qu’elle ou qu'il accomplit dans l'entreprise ainsi que les apprentissages que ces dernières lui permettent de réaliser.  </p>
        <h3>Objectifs  </h3>
        <p><ul><li>Objectiver de façon continue son vécu professionnel.</li>
        <li> Consigner ses réflexions. </li></ul></p>
        <h3> Directives</h3>
        <p> Tout au long de son stage, la ou le stagiaire doit complétéer des rapports d'étapes. <strong>Deux ou trois fois dans la session</strong>, elle ou il complète un rapport d'étape et le transmet à son superviseur de stage par l'entremise du site Web de stages. </p>
        <hr>		  
        <h3>Activités significatives :</h3>
        
        <div class="form-group">
            <label for="activity1">Veuillez entrer une première activité significative cette semaine :</label>
            <textarea id="activity1" name="activity1" required></textarea>
        </div>
        <div class="form-group">
            <label for="activity2">Veuillez entrer une deuxième activité significative cette semaine :</label>
            <textarea id="activity2" name="activity2" required></textarea>
        </div>
        <hr>
        <!-- Apprentissages réalisés : -->
        <h3>Apprentissages réalisés :</h3>
        <div class="form-group">
            <label for="learning1">Veuillez indiquer l'apprentissage relié à la première activité significative :</label>
            <textarea id="learning1" name="learning1" required></textarea>
        </div>
        <div class="form-group">
            <label for="learning2">Veuillez indiquer l'apprentissage relié à la deuxième activité significative :</label>
            <textarea id="learning2" name="learning2" required></textarea>
        </div>
        <hr>
        <!-- Difficultés rencontrées (s'il y a lieu) : -->
        <h3>Difficultés rencontrées (s'il y a lieu) :</h3>
        <div class="form-group">
            <label for="difficulty1">Veuillez indiquer une première difficulté rencontrée :</label>
            <textarea id="difficulty1" name="difficulty1" required></textarea>
        </div>
        <div class="form-group">
            <label for="difficulty2">Veuillez indiquer une deuxième difficulté rencontrée :</label>
            <textarea id="difficulty2" name="difficulty2" required></textarea>
        </div>
        <hr>
        <!-- Commentaires - Questions : -->
        <h3>Commentaires - Questions :</h3>
        <div class="form-group">
            <label for="comment1">Veuillez indiquer un premier commentaire ou une question pertinente :</label>
            <textarea id="comment1" name="comment1" required></textarea>
        </div>
        <div class="form-group">
            <label for="comment2">Veuillez indiquer un deuxième commentaire ou une question pertinente :</label>
            <textarea id="comment2" name="comment2" required></textarea>
        </div>
        

        <div class="form-group">
        <label for="date">Date:</label>
        <input type="text" id="date" name="date" value="<?php echo date('Y-m-d'); ?>" readonly required>
        </div>
        <input type="submit" value="Envoyer">
        <input type="reset" value="Réinitialiser">
    </form>
    </div>


<div>
<script>
    document.getElementById('myForm').addEventListener('submit', function(event) {
        // Reload the page when the form is submitted
        location.reload();
    });
</script>


</body>
</html>
