<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="initial-scale=1.0, user-scalable=no">
<meta charset="utf-8">
<title>exercice3 Google Maps</title>
<style>
  #map {
    height: 100%;
  }
  html, body {
    height: 100%;
    margin: 0;
    padding: 0;
  }
</style>
</head>
<body>
<div id="map"></div>
<script>
function initMap() {
  var map = new google.maps.Map(document.getElementById('map'), {
    zoom: 12,
    center: {lat: 45.444343, lng: -75.746633}
  });
  setMarkers(map);
}

var lots = [
  <?php
    // Connect to the database
    include "../bd.php";
    // Check connection
    if ($con->connect_error) {
      die("Connection failed: " . $con->connect_error);
    }

    // Query to get lots data
    $sql = "SELECT `Nom de l'employeur`, nocivic, latitude, longitude, googlemap FROM acces_employeurs";
    $result = $con->query($sql);

    // Fetch the data and convert to a JavaScript array
    if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()) {
        echo "['".$row['Nom de l\'employeur']."', '".$row['nocivic']."', ".$row['latitude'].", ".$row['longitude'].", ".$row['googlemap']."],";
      }
    } else {
      echo "[]";
    }

    // Close the database connection
    $con->close();
  ?>
];

function setMarkers(map) {
  var image = {
    url: '../img/beachflag.png',
    size: new google.maps.Size(20, 32),
    origin: new google.maps.Point(0, 0),
    anchor: new google.maps.Point(0, 32)
  };
  
  var shape = {
    coords: [1, 1, 1, 20, 18, 20, 18, 1],
    type: 'poly'
  };
  
  var infowindow = new google.maps.InfoWindow();
  
  for (var i = 0; i < lots.length; i++) {
    var lot = lots[i];
    var marker = new google.maps.Marker({
      animation: google.maps.Animation.DROP,
      position: {lat: lot[2], lng: lot[3]},
      map: map,
      icon: image,
      shape: shape,
      zIndex: lot[4]
    });

    google.maps.event.addListener(marker, 'mouseover', (function(marker, i) {
      return function() {
        infowindow.setContent("Nom de l'entreprise : " + lots[i][0] + "<br>" + "Adresse  : " + lots[i][2] + "<br>" + "<a href='http://www.cegepoutaouais.qc.ca' target='_blank'>Cégep</a>");
        infowindow.open(map, marker);
      }
    })(marker, i));
  }
}
</script>
<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCt_55rjBcDIiyP7m7Ln3sjD4T2Kxn3wbg&callback=initMap"></script>
</body>
</html>
