<?php
// Include database connection
ob_start();
include "bd.php";

// Check if a student number is passed as a query parameter
if (!isset($_GET['num'])) {
    echo "No superviseur selected for modification.";
    exit;
}

// Get the student number from the query parameter
$numsup = $_GET['num'];


// Fetch the student data to pre-fill the form
$sql = "SELECT nomsup, courriel, motdepasse FROM acces_adm WHERE noemploye = ?";
$stmt = $con->prepare($sql);
$stmt->bind_param("s", $numsup);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "superviseur not found.";
    exit;
}

$row = $result->fetch_assoc();
$stmt->close();



// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nomsup = $_POST['nomsup'];
    $courriel = $_POST['courriel'];
    $motdepasse = isset($_POST['motpasse']) ? trim($_POST['motpasse']) : '';
    $motdepasse2 = isset($_POST['motpasse2']) ? trim($_POST['motpasse2']) : '';

    

    // Validate inputs
    if (empty($nomsup) || empty($courriel)) {
        echo "Tous les champs obligatoires doivent être remplis.";
    } elseif ($motdepasse !== $motdepasse2) {
        echo "Les mots de passe ne correspondent pas.";
    } else {
        // If the password is not provided, keep the existing one
        if (empty($motdepasse)) {
            $motdepasse = $row['motdepasse'];
        }


        // Update the supervisor in `acces_adm`
        $update_sql = "UPDATE acces_adm 
                       SET nomsup = ?, courriel = ?, motdepasse = ?
                       WHERE noemploye = ?";
        $stmt = $con->prepare($update_sql);
        $stmt->bind_param('ssss', $nomsup, $courriel, $motdepasse, $numsup);

        if ($stmt->execute()) {
            // Update the supervisor's name in `journal`
            $update_journal_sql = "UPDATE journal 
                                   SET nomsup = ?
                                   WHERE nomsup = (SELECT nomsup FROM acces_adm WHERE noemploye = ?)";
            $journal_stmt = $con->prepare($update_journal_sql);
            $journal_stmt->bind_param('ss', $nomsup, $numsup); // Old name from the original fetch

            if ($journal_stmt->execute()) {
                header("Location: admin_superviseur.php?message=success");
                exit;
            } else {
                echo "Erreur lors de la mise à jour dans la table journal : " . $journal_stmt->error;
            }
        } else {
            echo "Erreur lors de la mise à jour : " . $stmt->error;
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier un superviseur</title>
</head>
<body>
    <h2>Modifier un superviseur</h2>
    <h4>Modifier le superviseur <?php echo htmlspecialchars($row['nomsup']); ?></h4>
    
    <form method="post" action="">
        
        <label for="nomsup">Nom du superviseur :</label><br />
        <input type="text" id="nomsup" name="nomsup" value="<?php echo htmlspecialchars($row['nomsup']); ?>" required><br />

        <label for="courriel">Courriel</label><br />
        <input type="email" id="courriel" name="courriel" value="<?php echo htmlspecialchars($row['courriel']); ?>" required><br />
                    

        <label for="motpasse">Mot de passe</label><br />
        <input type="password" id="motpasse" name="motpasse" maxlength="25"><br />
        <label for="motpasse2">Confirmer le mot de passe</label><br />
        <input type="password" id="motpasse2" name="motpasse2" maxlength="25"><br />


        <button type="submit">Modifier</button>
    </form>
    <br>
    <a href="admin_stagiaire.php">Retour à la liste des stagiaires</a>
</body>
</html>
