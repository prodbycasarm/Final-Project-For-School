<?php
session_start();

// Check if the user is not a student or not logged in
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'etudiant') {
    // Redirect to the login page or any other page as needed
    header("Location: index.php");
    exit();
}

include "bd.php"; // Assuming this file contains your database connection





// Check if the disconnect button is clicked
if (isset($_POST['disconnect'])) {
    // Destroy all session data
    session_unset();
    session_destroy();
    // Redirect to the login page or any other page as needed
    header("Location: index.php");
    exit();
}

// Initialize the session type variable
$_SESSION['type'] = "";

// Fetch data from the database
// Prepare SQL query
$sql_etudiant = "SELECT * FROM journal WHERE numetu = '{$_SESSION['user_id']}'";
$result_etudiant = mysqli_query($con, $sql_etudiant);

// Loop through the fetched data
while ($row = mysqli_fetch_assoc($result_etudiant)) {
    $_SESSION['type'] = $row['NomEtu'];
}



// Fetch data from the database
// Prepare SQL query
$sql_etudiant = "SELECT * FROM journal WHERE numetu = '{$_SESSION['user_id']}'";
$result_etudiant = mysqli_query($con, $sql_etudiant);

// Check if there is a row fetched
if ($row = mysqli_fetch_assoc($result_etudiant)) {
    // Retrieve and store values from the fetched row
    $userName = $row['NomEtu']; // Assuming 'NomEtu' is the column you want to store as the user's name
    $userSupervisor = $row['nomsup']; // Assuming 'nomsup' is the column for supervisor's name
} else {
    // If no row is fetched, set $userName and $userSupervisor to empty strings or handle it as needed
    $userName = "";
    $userSupervisor = "";
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $date = $_POST['date'];
    $activity1 = $_POST['activity1'];
    $activity2 = $_POST['activity2'];
    $learning1 = $_POST['learning1'];
    $learning2 = $_POST['learning2'];
    $difficulty1 = $_POST['difficulty1'];
    $difficulty2 = $_POST['difficulty2'];
    $comment1 = $_POST['comment1'];
    $comment2 = $_POST['comment2'];

    // Insert data into the database including the user's name
    $sql_insert = "INSERT INTO journal (numetu, NomEtu, nomsup, DateJournal, AS1, AS2, AR1, AR2, DR1, DR2, C1, C2) VALUES ('{$_SESSION['user_id']}', '$userName', '$userSupervisor', '$date', '$activity1', '$activity2', '$learning1', '$learning2', '$difficulty1', '$difficulty2', '$comment1', '$comment2')";

    if (mysqli_query($con, $sql_insert)) {
        echo "Nouveau Rapport Enrigistré";
    } else {
        echo "Error: " . $sql_insert . "<br>" . mysqli_error($con);
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Évaluation de l'entreprise - 2023 Etudiant</title>
    <style>
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
            }
        /* Container for the main content */
        .container {
   
            padding: 20px;
            display: flex;
            gap: 20px;
     
        }

        /* Styles for the table */
        table {
            border-collapse: collapse;
            width: 80%;
            margin: 20px auto;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 15px;
            text-align: left;
            color: #333;
        }
        
        .column {
            flex: 1; /* Equal width for both columns */
        }
        th {
            background-color: #3A3B3C;
            color: #f2f2f2;
            font-weight: bold;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #e2e3e5;
        }

        /* Navbar styles */
        nav {
            width: 100%;
            background: #242526;
            border-bottom: 2px white solid;
        }

        nav .wrapper {
            max-width: 1300px;
            padding:30px;
            height: 70px;
            line-height: 70px;
            margin: auto;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .wrapper .logo a {
            color: #f2f2f2;
            font-size: 30px;
            font-weight: 600;
            text-decoration: none;
        }

        .nav-links {
            display: inline-flex;
        }

        .nav-links li {
            list-style: none;
        }

        .nav-links li a {
            color: white;
            text-decoration: none;
            font-size: 18px;
            font-weight: 500;
            padding: 9px 15px;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        .sub-menu {
            color: black !important;
        }
  
        .nav-links li a:hover {
            background: #3A3B3C;
            color: white !important;
        }

        /* Header and Title Styles */
        .header {
            background-color: white;
            color: black;
        }

        .titre h1 {
            color: white;
        }
        .header .wrapper {
            display: flex;
            flex-direction: column;
            padding:10px;
            align-items: center; /* Center the menu horizontally */
            text-align: center;
        }

        .header .nav-links {
            display: flex;
            justify-content: center; /* Center menu items within the flex container */
            gap: 15px; /* Optional: space between menu items */
            padding: 20px;
            
        }

        .tous {
            margin-top: 40px;
            text-align: left;
            width: 70%;
            margin: 20px auto;
        }

        /* Responsive adjustments */
        @media screen and (max-width: 970px) {
            .wrapper .nav-links {
                position: fixed;
                height: 100vh;
                width: 100%;
                max-width: 350px;
                top: 0;
                left: -100%;
                background: #242526;
                padding: 50px 10px;
                line-height: 50px;
                box-shadow: 0px 15px 15px rgba(0, 0, 0, 0.18);
                transition: all 0.3s ease;
            }

            .nav-links li {
                margin: 15px 10px;
            }

            .nav-links li a {
                font-size: 20px;
                display: block;
                padding: 0 20px;
            }
        }
        .rapport-link {
            color:black;
        }
        .tableau {
            background-color: #dadada;
            padding: 50px;
            width: 70%;
            margin: 0 auto; /* Centers the container horizontally */
        }
        
        p{
            padding-top: 10px;
            padding-bottom: 10px;
        }
        h3{
            padding-top: 10px;
            padding-bottom: 10px;
        }
        .form-group{
            padding-top: 10px;
            padding-bottom: 10px;
        }
        .text {
            display: flex;
            justify-content: space-between;
            align-items: center; /* Aligns items vertically in the center */
        }

    .text h2 {
            margin: 0; /* Remove any default margin if necessary */
            font-size:30px;
        }

    .text .text1 {
            margin: 0; /* Remove any default margin if necessary */
            text-align: right;
            font-weight: bold;
        }
        .special-hr{
            margin-top: 10px;
            margin-bottom: 40px;
        }
        .bullet_point ul {
            padding-left: 20px; /* Adds indentation to the entire list */
        }

        .bullet_point li {
            text-indent: -10px; /* Optional: further control bullet position */
            padding-left: 10px; /* Aligns the text with the bullet */
        }

        /* Container for rows */
        .row {
            display: flex;
            flex-wrap: wrap; /* Allows columns to wrap into new rows */
            margin: 0 -15px; /* Optional: adjusts for column padding */
        }

        /* Column styling */
        [class*="col-"] {
            padding: 0 15px; /* Optional: space between columns */
            box-sizing: border-box;
        }

        /* General reset and styling for form elements */


        

        

        /* Column widths in 5% increments */
        .col-5  { flex: 0 0 5%;  max-width: 5%; }
        .col-10 { flex: 0 0 10%; max-width: 10%; }
        .col-15 { flex: 0 0 15%; max-width: 15%; }
        .col-20 { flex: 0 0 20%; max-width: 20%; }
        .col-25 { flex: 0 0 25%; max-width: 25%; }
        .col-30 { flex: 0 0 30%; max-width: 30%; }
        .col-35 { flex: 0 0 35%; max-width: 35%; }
        .col-40 { flex: 0 0 40%; max-width: 40%; }
        .col-45 { flex: 0 0 45%; max-width: 45%; }
        .col-50 { flex: 0 0 50%; max-width: 50%; }
        .col-55 { flex: 0 0 55%; max-width: 55%; }
        .col-60 { flex: 0 0 60%; max-width: 60%; }
        .col-65 { flex: 0 0 65%; max-width: 65%; }
        .col-70 { flex: 0 0 70%; max-width: 70%; }
        .col-75 { flex: 0 0 75%; max-width: 75%; }
        .col-80 { flex: 0 0 80%; max-width: 80%; }
        .col-85 { flex: 0 0 85%; max-width: 85%; }
        .col-90 { flex: 0 0 90%; max-width: 90%; }
        .col-95 { flex: 0 0 95%; max-width: 95%; }
        .col-100 { flex: 0 0 100%; max-width: 100%; }

        /* Responsive stacking on small screens */
        @media (max-width: 768px) {
            [class*="col-"] {
                flex: 0 0 100%; /* Full width on small screens */
                max-width: 100%;
            }
        }


    textarea {
        height:150px;
        width:100%;
        vertical-align:middle;
        padding:15px;
        letter-spacing:0.17em;
        margin-bottom:10px;
        border-radius: 4px 4px 4px 4px;
        background-color:#FFF !important;
        }

    form {
        padding:10px;
        border-radius:15px;
        
    }

    fieldset {
    display:block;

    }
    </style>
</head>
<body>
<div class="main">
    <nav>
        <div class="wrapper">
            <div class="titre">
                <h1 href="#">Stage technique d'intégration multimédia</h1>
            </div>
            <ul class="nav-links">
                <label for="close-btn" class="btn close-btn"><i class="fas fa-times"></i></label>
                <li style="color:white; font-size:18px;"><?php echo $_SESSION['type']; ?> | </li>
                <li><a href="dash_etudiant.php">Accueil</a></li>
                <li id="disconnect"><a>Déconnecter</a></li>
            </ul>
            <label for="menu-btn" class="btn menu-btn"><i class="fas fa-bars"></i></label>
        </div>
    </nav>

    <div class="header">
        <div class="wrapper">
            <ul class="nav-links">
                <li><a class="sub-menu" href="page_etudiant.php">Rapports d'étape</a></li>
                <li><a class="sub-menu" href="experience.php">Expériences de stage</a></li>
                <li><a class="sub-menu" href="#">Évaluation de l'entreprise</a></li>
            </ul> 
        </div>
    </div>

    <!-- Hidden form for logout -->
    <form id="logoutForm" method="post" action="">
        <input type="hidden" name="disconnect">
    </form>

    <div class="tableau">
        <div class="text">        <!-- FORMS -->
            <h3>Évaluation de l'entreprise</h3>
            <p class="create">Évaluation de l'entreprise créé par <?php echo $userName; ?> le <?php echo date('j-m-y'); ?></p>
        </div>
        
        <hr style="margin-bottom:10px;">

        <form name="evalstage" action="" method="post">
		   
			<legend>1. Parmi les objectifs que vous avez retenus à l'intérieur du plan de votre stage, lesquels avez-vous atteints ? </legend> 
            
            <hr style="margin-top:20px;">
            <p>Pour vous aider à les identifier, consultez votre plan, ANNEXE 1, et vos rapports de stage, ANNEXE 2.	 <br /><br /></legend>
			Attitudes personnelles (objectifs g&eacute;n&eacute;raux) :</p>

            <div class="container">
                <p class="col-50"><label class="label_txt" for="question1a">a. </label>
                <textarea name="champ1" id="question1a" cols="50" rows="8" class="requis"></textarea></p>	
                
                <p class="col-50"><label class="label_txt" for="question1b">b.</label>
                <textarea name="champ2" id="question1b" cols="50" rows="8" class="requis"></textarea> </p>
                <div style="clear:both"></div>
            </div>
            
            <p>Habilet&eacute;s professionnelles (objectifs sp&eacute;cifiques) :</p>
            <div class="container">
                
                <p class="col-50"><label class="label_txt" for="question1a-2">a.</label>
                <textarea name="champ3" id="question1a-2" cols="50" rows="8" class="requis"></textarea></p>
                
                <p class="col-50"><label class="label_txt" for="question1b-2">b.</label>
                <textarea name="champ4" id="question1b-2" cols="50" rows="8" class="requis"></textarea></p>
            </div>
			
            
            <label class="label_txt" for="question1-5">Pourquoi et comment &ecirc;tes-vous parvenue ou parvenu &agrave; atteindre ces objectifs ?</label>	
			<textarea name="champ5" id="question1-5" cols="50" rows="8" class="requis"></textarea>
		 
		  
		  
			<legend>2. S'il y a lieu, identifiez quelques objectifs que vous n&rsquo;avez pas atteints de fa&ccedil;on satisfaisante.</legend>
			<p>Attitudes personnelles :</p>	
			<div class="container">
                <p class="col-50"><label class="label_txt" for="question2a">a.</label>
                <textarea name="champ6" id="question2a" cols="50" rows="8" class="requis"></textarea></p>
                <p class="col-50"><label class="label_txt" for="question2b">b.</label>
                <textarea name="champ7" id="question2b" cols="50" rows="8" class="requis"></textarea></p>
                <div style="clear:both"></div>
			</div>

			<p>Habilet&eacute;s professionnelles</p>
            <div class="container">
			<p class="col-50"><label class="label_txt" for="question2a-2">a.</label>
			<textarea name="champ8" id="question2a-2" cols="50" rows="8" class="requis"></textarea></p>
			<p class="col-50"><label class="label_txt" for="question2b-2">b.</label>
			<textarea name="champ9" id="question2b-2" cols="50" rows="8" class="requis"></textarea></p>
            </div>

			<p><label class="label_txt" for="question2-5">Pourquoi n'avez-vous pas r&eacute;ussi &agrave; les atteindre ?</label>
			</p>
            <textarea name="champ10" id="question2-5" cols="50" rows="8" class="requis"></textarea>
		 
		  
		  
			<legend><label class="label_txt_num" for="question3a">3. S'il y a lieu, identifiez les craintes que vous aviez au regard du stage avant de l'entreprendre ?</label></legend>
			<textarea name="champ11" id="question3a" cols="50" rows="8" class="requis"></textarea>
			<label class="label_txt" for="question3b">Parmi vos craintes (si vous en aviez), lesquelles &eacute;taient justifi&eacute;es et lesquelles ne l'&eacute;taient pas ? </label>
			<p>Commentez tr&egrave;s bri&egrave;vement votre r&eacute;ponse.</p>	
			<textarea name="champ12" id="question3b" cols="50" rows="8" class="requis"></textarea> 
		  
		  
		     
			<legend>4. Identifiez les impacts que votre s&eacute;jour en entreprise a eus sur vous, d 'une part, et sur l'entreprise, d 'autre part.</legend>
			<label class="label_txt" for="question4a">a. Pour vous : (votre vie personelle, vos &eacute;tudes, etc.)</label>
			<textarea name="champ13" id="question4a" cols="50" rows="8" class="requis"></textarea>
			<label class="label_txt" for="question4b">b. Pour l'entreprise :</label>
			<textarea name="champ14" id="question4b" cols="50" rows="8" class="requis"></textarea>
		  
		  
		    
			<legend><label class="label_txt_num" for="question5">5. Votre stage affectera-t-il votre orientation professionnelle ?</label></legend>
			<p>Justifiez votre r&eacute;ponse.</p>
			<textarea name="champ15" id="question5" cols="50" rows="8" class="requis"></textarea>
		  
		  
		   
			<legend><label class="label_txt_num" for="question6">6. En quoi votre stage a-t-il valid&eacute; ou plus ou moins invalid&eacute; la formation que vous avez re&ccedil;ue au C&eacute;gep de l&rsquo;Outaouais ?</label></legend>	
			<textarea name="champ16" id="question6" cols="50" rows="8" class="requis"></textarea>
		 
		  
		   
			<legend><label class="label_txt_num" for="question7">7. Suite &agrave; l'exp&eacute;rience que vous avez v&eacute;cue en entreprise, pouvez-vous d&eacute;gager une ou des faiblesses qu'aurait votre formation ?</label></legend>
			<p>Si oui, lesquelles ?</p>
			<textarea name="champ17" id="question7" cols="50" rows="8" class="requis"></textarea>
		  
		  
		 
			<legend><label class="label_txt_num" for="question8"> 
			8. Suite &agrave; l'exp&eacute;rience que vous avez v&eacute;cue en stage, identifiez, s'il y a lieu, les &eacute;l&eacute;ments qui devraient pr&eacute;f&eacute;rablement &ecirc;tre ajout&eacute;s &agrave; notre programme. </label></legend>	
			<textarea name="champ18" id="question8" cols="50" rows="8" class="requis"></textarea>
		  
		 	
		
			
			  <input  type="submit" name="envoyer" value="envoyer" class="mybutton1" />
			  <input type="reset" name="Réinitialiser" value="Réinitialiser"  class="mybutton2" />
			
		</form>
            </div>
</div> <!-- Main -->


<!-- Pour l'option si non -->
<script>
  // Get the radio buttons and the text input
  const radioOui = document.getElementById("q1_a");
  const radioNon = document.getElementById("q1_b");
  const inputText = document.getElementById("q1_autre");

  // Function to enable/disable the text input based on the selection
  function toggleInput() {
    inputText.disabled = !radioNon.checked;
  }

  // Add event listeners for the radio buttons
  radioOui.addEventListener("change", toggleInput);
  radioNon.addEventListener("change", toggleInput);
</script>

<script>
        document.getElementById('disconnect').addEventListener('click', function() {
            // Submit the form when the "Déconnecter" li element is clicked
            document.getElementById('logoutForm').submit();
        });
</script>

<script>
    document.getElementById('myForm').addEventListener('submit', function(event) {
        // Reload the page when the form is submitted
        location.reload();
    });
</script>


</body>
</html>
