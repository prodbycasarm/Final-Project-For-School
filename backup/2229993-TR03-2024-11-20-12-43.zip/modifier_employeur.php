<?php
// Include database connection
include "bd.php";

// Check if a student number (superviseur ID) is passed as a query parameter
if (!isset($_GET['num'])) {
    echo "Aucun employeur sélectionné pour modification.";
    exit;
}

// Get the superviseur number from the query parameter
$noemployeur = $_GET['num'];

// Fetch the superviseur data to pre-fill the form
$sql = "SELECT `Nom de l'employeur`, `Nom de l'entreprise`, mdpemployeur FROM acces_employeurs WHERE noemployeur = ?";
$stmt = $con->prepare($sql);
$stmt->bind_param("s", $noemployeur);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "Employeur introuvable.";
    exit;
}

$row = $result->fetch_assoc();
$stmt->close();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the form inputs
    $nomemployeur = isset($_POST['nomsup']) ? trim($_POST['nomsup']) : '';
    $nomdelentreprise = isset($_POST['nomdelentreprise']) ? trim($_POST['nomdelentreprise']) : '';
    $motdepasse = isset($_POST['motpasse']) ? trim($_POST['motpasse']) : '';
    $motdepasse2 = isset($_POST['motpasse2']) ? trim($_POST['motpasse2']) : '';

    // Validate inputs
    if (empty($nomemployeur) || empty($nomdelentreprise)) {
        echo "Tous les champs obligatoires doivent être remplis.";
    } elseif ($motdepasse !== $motdepasse2) {
        echo "Les mots de passe ne correspondent pas.";
    } else {
        // If the password is not provided, keep the existing one
        if (empty($motdepasse)) {
            $motdepasse = $row['mdpemployeur'];
        }

        // Update the employeur data
        $update_sql = "UPDATE acces_employeurs 
                       SET `Nom de l'employeur` = ?, `Nom de l'entreprise` = ?, mdpemployeur = ?
                       WHERE noemployeur = ?";
        $stmt = $con->prepare($update_sql);
        $stmt->bind_param('ssss', $nomemployeur, $nomdelentreprise, $motdepasse, $noemployeur);

        if ($stmt->execute()) {
            header("Location: admin_employeur.php?message=success");
            exit;
        } else {
            echo "Erreur lors de la mise à jour : " . $stmt->error;
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier un employeur</title>
</head>
<body>
    <h2>Modifier un employeur</h2>
    <h4>Modifier l'employeur <?php echo htmlspecialchars($row['Nom de l\'employeur']); ?></h4>
    <form method="post" action="">
        <label for="nomsup">Nom de l'employeur*</label><br />
        <input type="text" id="nomsup" name="nomsup" value="<?php echo htmlspecialchars($row['Nom de l\'employeur']); ?>" required><br />

        <label for="nomdelentreprise">Nom de l'entreprise*</label><br />
        <input type="text" id="nomdelentreprise" name="nomdelentreprise" value="<?php echo htmlspecialchars($row['Nom de l\'entreprise']); ?>" required><br />

        <label for="motpasse">Mot de passe</label><br />
        <input type="password" id="motpasse" name="motpasse" maxlength="25"><br />
        <label for="motpasse2">Confirmer le mot de passe</label><br />
        <input type="password" id="motpasse2" name="motpasse2" maxlength="25"><br />

        <button type="submit">Modifier</button>
    </form>
</body>
</html>
