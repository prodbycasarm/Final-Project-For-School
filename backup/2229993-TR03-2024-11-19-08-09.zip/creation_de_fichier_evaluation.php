<?php
session_start();

// Assurez-vous que l'utilisateur est connecté
if (!isset($_SESSION['username1'])) {
    die("Vous devez être connecté pour soumettre ce formulaire.");
}

// Récupérer les données du formulaire
$username = $_SESSION['username1']; // Nom d'utilisateur connecté
$question1 = htmlspecialchars($_POST['question1']);
$response1 = htmlspecialchars($_POST['response1']);
$question2 = htmlspecialchars($_POST['question2']);
$response2 = htmlspecialchars($_POST['response2']);

// Créer le contenu du fichier HTML
$htmlContent = <<<HTML
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Réponses de $username</title>
</head>
<body>
    <h1>Réponses de $username</h1>
    <ul>
        <li><strong>$question1:</strong> $response1</li>
        <li><strong>$question2:</strong> $response2</li>
    </ul>
</body>
</html>
HTML;

// Vérifier si le dossier "stagiaires" existe, sinon le créer
$directory = __DIR__ . '/stagiaires';
if (!is_dir($directory)) {
    mkdir($directory, 0755, true);
}

// Créer un fichier HTML unique pour chaque utilisateur
$filename = $directory . '/' . $username . '.html';

// Écrire le contenu dans le fichier
if (file_put_contents($filename, $htmlContent)) {
    echo "Fichier créé avec succès : <a href='stagiaires/$username.html'>Voir le fichier</a>";
} else {
    echo "Erreur lors de la création du fichier.";
}
?>
