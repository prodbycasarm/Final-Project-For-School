<?php
// Include database connection
ob_start();
include "bd.php";

// Check if a student number (superviseur ID) is passed as a query parameter
if (!isset($_GET['num'])) {
    echo "Aucun employeur sélectionné pour modification.";
    exit;
}

// Get the superviseur number from the query parameter
$nostagiaire = $_GET['num'];

// Fetch the superviseur data to pre-fill the form
$sql = "SELECT 
                acces_etu.numetu, 
                acces_etu.nometu, 
                acces_etu.nomsup, 
                acces_etu.noemployeur, 
                acces_etu.motdepasse,
                acces_employeurs.`Nom de l'employeur`,
                acces_employeurs.`Nom de l'entreprise`
            FROM acces_etu
            INNER JOIN acces_employeurs 
            ON acces_etu.noemployeur = acces_employeurs.noemployeur
            WHERE acces_etu.numetu = ?";  // Add a WHERE clause to filter by numetu

$stmt = $con->prepare($sql);
$stmt->bind_param("s", $nostagiaire);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "Étudiant introuvable.";
    exit;
}

$row = $result->fetch_assoc();
$stmt->close();

// Fetch employeurs for the "milieu de stage" dropdown
$noemployeur_sql = "SELECT noemployeur, `Nom de l'employeur`, `Nom de l'entreprise` FROM acces_employeurs";
$noemployeur_result = $con->query($noemployeur_sql);

// Fetch superviseurs for the "superviseur" dropdown
$nomsup_sql = "SELECT noemploye, nomsup FROM acces_adm"; // Adjust table name if needed
$nomsup_result = $con->query($nomsup_sql);
// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the form inputs
    $nometu = isset($_POST['nometu']) ? trim($_POST['nometu']) : '';
    $nomsup = isset($_POST['nomsup']) ? trim($_POST['nomsup']) : '';  // Correct field name
    $noemployeur = isset($_POST['noemployeur']) ? trim($_POST['noemployeur']) : '';
    $motdepasse = isset($_POST['motdepasse']) ? trim($_POST['motdepasse']) : '';
    $motdepasse2 = isset($_POST['motdepasse2']) ? trim($_POST['motdepasse2']) : '';

    // Validate inputs
    if (empty($nometu)) {
        echo "Tous les champs obligatoires doivent être remplis.";
    } elseif ($motdepasse !== $motdepasse2) {
        echo "Les mots de passe ne correspondent pas.";
    } else {
        // If the password is not provided, keep the existing one
        if (empty($motdepasse)) {
            $motdepasse = $row['motdepasse']; // Use the current password if it's not provided
        }
        
        // Handle the case where no employer is selected
        if ($noemployeur === 'nepasassocier') {
            $noemployeur = null;  // If no employer is selected, set it as NULL or handle accordingly
        }
        
        // Handle the case where no supervisor is selected
        if ($nomsup === 'nepasassocier') {
            $nomsup = null;  // If no supervisor is selected, set it as NULL or handle accordingly
        }

        // Update the database
        $update_sql = "UPDATE acces_etu
               SET nometu = ?, nomsup = ?, noemployeur = ?, motdepasse = ? 
               WHERE numetu = ?";

        $stmt = $con->prepare($update_sql);
        $stmt->bind_param('sssss', $nometu, $nomsup, $noemployeur, $motdepasse, $nostagiaire);

        if ($stmt->execute()) {
            // Update the "NomEtu" field in the journal table
            $update_journal_sql = "UPDATE journal 
                                   SET NomEtu = ?, nomsup = ?
                                   WHERE numetu = ?";
            
            $journal_stmt = $con->prepare($update_journal_sql);
            $journal_stmt->bind_param('sss', $nometu, $nomsup, $nostagiaire);
        
            if ($journal_stmt->execute()) {
                header("Location: admin_stagiaire.php?message=success");
                exit;
            } else {
                echo "Erreur lors de la mise à jour dans la table journal : " . $journal_stmt->error;
            }
            $journal_stmt->close();
        } else {
            echo "Erreur lors de la mise à jour : " . $stmt->error;
        }
        $stmt->close();
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier un stagiaire</title>
</head>
<body>
    <h2>Modifier un stagiaire</h2>
    <h4>Modifier le stagiaire <?php echo htmlspecialchars($row['nometu']); ?></h4>
    <form method="post" action="">
        <label for="nometu">Nom du stagiaire*</label><br />
        <input type="text" id="nometu" name="nometu" value="<?php echo htmlspecialchars($row['nometu']); ?>" required><br />
        
        <label>Associer un milieu de stage</label><br />
        <select id="noemployeur" name="noemployeur" style="float:left; margin-bottom:19px;">
            <option value="nepasassocier">Ne pas associer tout de suite</option>
            <option value="" disabled="disabled">---Milieux de stage---</option>
            <?php
            // Populate the "milieu" dropdown with employeurs from the database
            while ($noemployeur = $noemployeur_result->fetch_assoc()) {
                $selected = ($row['noemployeur'] == $noemployeur['noemployeur']) ? 'selected' : '';
                // Corrected the concatenation of both "Nom de l'employeur" and "Nom de l'entreprise"
                echo "<option value=\"{$noemployeur['noemployeur']}\" $selected>{$noemployeur['Nom de l\'employeur']} - {$noemployeur['Nom de l\'entreprise']}</option>";
            }
            ?>
        </select><br /><br><br>

        <label>Associer un superviseur</label><br />
        <select id="nomsup" name="nomsup">
            <option value="nepasassocier">Ne pas associer tout de suite</option>
            <option value="" disabled="disabled">---Superviseurs---</option>
            <?php
            // Populate the "superviseur" dropdown with superviseurs from the database
            while ($nomsup = $nomsup_result->fetch_assoc()) {
                $selected = ($row['nomsup'] == $nomsup['nomsup']) ? 'selected' : '';
                echo "<option value=\"{$nomsup['nomsup']}\" $selected>{$nomsup['nomsup']}</option>";
            }
            ?>
        </select><br />
        
        <label for="motdepasse">Mot de passe</label><br />
        <input type="password" id="motdepasse" name="motdepasse" maxlength="25"><br />
        <label for="motdepasse2">Confirmer le mot de passe</label><br />
        <input type="password" id="motdepasse2" name="motdepasse2" maxlength="25"><br />

        <button type="submit">Modifier</button>
    </form>
</body>
</html>
