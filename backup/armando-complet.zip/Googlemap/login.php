<?php 
  
  // Database connection details
  $host = 'localhost';
  $dbname = 'casarm_PROPRIO';
  $user = 'test1';
  $pass = '%Qt@n6EvVyA#';
  
  try {
      // Create a new PDO instance
      $conn = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  
      if ($_SERVER['REQUEST_METHOD'] == 'POST') {
          // Get input from the form
          $username1 = $_POST['username1'];
          $password = $_POST['password'];
  
          // SQL query to get user data
          $stmt = $conn->prepare('SELECT * FROM users WHERE username1 = :username1');
          $stmt->execute(['username1' => $username1]);
          $user = $stmt->fetch(PDO::FETCH_ASSOC);
  
          // Check if user exists and passwords match
          if ($user && password_verify($password, $user['password'])) {
              $_SESSION['user_id'] = $user['id'];
              $_SESSION['username1'] = $user['username1'];
              echo "Login successful! Welcome, " . htmlspecialchars($username1);
          } else {
              echo "Invalid username or password!";
          }
      }
  } catch (PDOException $e) {
      echo "Error: " . $e->getMessage();
  }
    ?>